namespace Essai
open System

module Bibliotheque =
    let ajoute42    = (+) 42
    let carre x     = x * x
    let decremente  = (-) 1
