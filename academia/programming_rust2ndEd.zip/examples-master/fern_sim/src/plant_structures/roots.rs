#![allow(dead_code)]

pub struct Root {
    pub x: bool
}

pub type RootSet = Vec<Root>;
