#![allow(dead_code)]
//! Simulation of individual leaves (for the formation of leaves, see `stem`).

pub struct Leaf {
    pub x: bool
}
