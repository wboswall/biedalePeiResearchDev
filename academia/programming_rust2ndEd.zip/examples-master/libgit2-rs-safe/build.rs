fn main() {
    println!("cargo:rustc-link-search=native=/home/jimb/libgit2-0.25.1/build");
}
