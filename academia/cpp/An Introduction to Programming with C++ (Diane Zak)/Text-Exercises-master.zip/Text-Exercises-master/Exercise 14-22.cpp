//Introduction to Programming with C++ (6th ed) <Diane Zak>
//Chapter 14 Exercise 22 Intermediate22
//created/revised by <Rex Jepson> <10-18-2015>

#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include <string>

using namespace std;

int main()
{
    //declare variables

    // enter input items

    //enter function

    //display output

    cin.get();
    return 0;
}//end main function
