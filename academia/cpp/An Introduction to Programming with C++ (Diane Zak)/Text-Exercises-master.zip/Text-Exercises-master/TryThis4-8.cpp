//Intorduction to Programming with C++ (Diane Zak)
//chapter 4, exercise TryThis8,
//created/revised by <Rex Jepson> <9/13/2015>
#include <iostream>
using namespace std;

int main()
{
    //declare variables for sales  commission rate, total sales and final commission
    double sale1 = 0.0;
    double sale2 = 0.0;
    double commissionRate = 0.0;
    double totalSales = 0.0;
    double commission = 0.0;

    //enter sales and commision rate
    cout << "First sale? ";
    cin >> sale1;
    cout << "Second Sale? ";
    cin >> sale2;
    cout << "Commission rate in decimal format? ";
    cin >> commissionRate;

    //calculate total sales and commission
    totalSales = sale1 + sale2;
    commission = totalSales * commissionRate;

    //display the commission
    cout << "Commission: $" << commission << endl;

    return 0;
}   //end of main function
