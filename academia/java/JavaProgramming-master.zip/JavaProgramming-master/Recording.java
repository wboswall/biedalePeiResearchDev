
public class Recording {
	private String title;
	private String artist;
	private int playingTime;
	
	public void setTitle(String t){
		title = t;
	}
	public String getTitle(){
		return title;
	}
	
	public void setArtist(String a){
		artist = a;
	}
	public String getArtist(){
		return artist;
	}
	
	public void setPlayingTime(int p){
		playingTime = p;
	}
	public int getPlayingTime(){
		return playingTime;
	}
}
